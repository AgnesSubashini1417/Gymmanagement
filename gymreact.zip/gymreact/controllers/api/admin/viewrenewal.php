<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Access-Control-Allow-Credentials: true");
header('Content-Type: application/json');

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "gymreact";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Connection failed: ' . $conn->connect_error]));
}

// Fetch all renewal records
$sql = "SELECT id, Name, Membership, Amount, enddate FROM paymentdetails";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $renewals = [];
    while ($row = $result->fetch_assoc()) {
        $renewals[] = $row;
    }
    echo json_encode(['success' => true, 'renewals' => $renewals]);
} else {
    echo json_encode(['success' => false, 'message' => 'No renewal records found']);
}

$conn->close();
?>
