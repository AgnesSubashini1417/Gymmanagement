<?php
// CORS headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Access-Control-Allow-Credentials: true");

// Set content type to JSON
header('Content-Type: application/json');

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "gymreact";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Connection failed: ' . $conn->connect_error]));
}

// Query to get total online users from userlogin table
$sqlOnline = "SELECT COUNT(*) AS total_online FROM userlogin";
$resultOnline = $conn->query($sqlOnline);
if (!$resultOnline) {
    die(json_encode(['success' => false, 'message' => 'Query Error (Online): ' . $conn->error]));
}
$totalOnline = ($resultOnline->num_rows > 0) ? $resultOnline->fetch_assoc()['total_online'] : 0;

// Query to get total offline users from offline table
$sqlOffline = "SELECT COUNT(*) AS total_offline FROM offline";
$resultOffline = $conn->query($sqlOffline);
if (!$resultOffline) {
    die(json_encode(['success' => false, 'message' => 'Query Error (Offline): ' . $conn->error]));
}
$totalOffline = ($resultOffline->num_rows > 0) ? $resultOffline->fetch_assoc()['total_offline'] : 0;

// Query to get total offers

// Return JSON response
echo json_encode([
    'success' => true,
    'totalOnlineUsers' => $totalOnline,
    'totalOfflineUsers' => $totalOffline,
    
]);

$conn->close();
?>
