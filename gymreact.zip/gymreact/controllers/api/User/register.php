<?php
// CORS headers to allow all origins (can be restricted to specific domains if needed)
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Access-Control-Allow-Credentials: true");

// Set the content type to JSON
header('Content-Type: application/json');

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "gymreact";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Connection failed: ' . $conn->connect_error]));
}

// Decode incoming JSON data
$data = json_decode(file_get_contents("php://input"), true);

// Check if the data is valid
if (!isset($data['name'], $data['age'], $data['gender'], $data['email'], $data['password'], $data['phone'],$data['Address'],$data['city'])) {
    echo json_encode(['success' => false, 'message' => 'Missing required fields']);
    exit;
}

// Get POST data from JSON
$name = $data['name'];
$age = $data['age'];
$gender=$data['gender'];
$email = $data['email'];
$password = $data['password'];
$phone = $data['phone'];
$Address = $data['Address'];
$city = $data['city'];


// Check if student exists
$check = "SELECT * FROM userlogin WHERE name = '$name'";
$result = $conn->query($check);

if ($result->num_rows > 0) {
    // Update if student exists
    $sql = "UPDATE userlogin SET name='$name',age='$age',gender='$gender', email='$email',password='$password', phone='$phone', Address='$Address', city='$city' WHERE name='$name'";
} else {
    // Insert if student doesn't exist
    $sql = "INSERT INTO userlogin (name, age,gender, email, password, phone,Address, city) VALUES ('$name', '$age','$gender', '$email', '$password', '$phone', '$Address','$city')";
}

if ($conn->query($sql) === TRUE) {
    echo json_encode(['success' => true, 'message' => 'Student saved successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Error: ' . $conn->error]);
}

$conn->close();
?>
