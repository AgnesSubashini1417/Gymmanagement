<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Access-Control-Allow-Credentials: true");
header('Content-Type: application/json');

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "gymreact";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Connection failed: ' . $conn->connect_error]));
}

$data = json_decode(file_get_contents("php://input"), true);
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($data['id'])) {
    $id = $data['id'];
    $new_end_date = date('Y-m-d', strtotime("+1 month")); // Extend by 1 month

    $updateQuery = "UPDATE paymentdetails SET enddate = '$new_end_date' WHERE id = '$id'";
    if ($conn->query($updateQuery) === TRUE) {
        echo json_encode(['success' => true, 'message' => 'Renewal successful', 'new_end_date' => $new_end_date]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Renewal failed']);
    }
}

$conn->close();
?>
