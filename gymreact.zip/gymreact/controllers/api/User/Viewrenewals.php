<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Access-Control-Allow-Credentials: true");
header('Content-Type: application/json');

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "gymreact";

// Connect to the database
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Connection failed: ' . $conn->connect_error]));
}

// Get the user name from the request
if (!isset($_GET['name'])) {
    echo json_encode(['success' => false, 'message' => 'User name is required']);
    exit();
}

$userName = $conn->real_escape_string($_GET['name']);

// Fetch renewal records for the logged-in user
$sql = "SELECT id, Name, Membership,Trainingplan, Amount, enddate FROM paymentdetails WHERE Name = '$userName'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $renewals = [];
    while ($row = $result->fetch_assoc()) {
        $renewals[] = $row;
    }
    echo json_encode(['success' => true, 'renewals' => $renewals]);
} else {
    echo json_encode(['success' => false, 'message' => 'No renewal records found']);
}

$conn->close();
?>
