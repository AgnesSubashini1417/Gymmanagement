<?php
// CORS headers to allow all origins (can be restricted to specific domains if needed)
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Access-Control-Allow-Credentials: true");

// Set the content type to JSON
header('Content-Type: application/json');

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "gymreact";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Connection failed: ' . $conn->connect_error]));
}

// Decode incoming JSON data
$data = json_decode(file_get_contents("php://input"), true);

// Check if the data is valid
if (!isset($data['Membership'], $data['Trainingplan'], $data['Amount'], $data['Name'], $data['joindate'], $data['enddate'])) {
    echo json_encode(['success' => false, 'message' => 'Missing required fields']);
    exit;
}

// Get POST data from JSON
$Membership = $data['Membership'];
$Trainingplan= $data['Trainingplan'];
$Amount=$data['Amount'];
$Name = $data['Name'];
$joindate = $data['joindate'];
$enddate = $data['enddate'];



// Check if student exists
$check = "SELECT * FROM paymentdetails WHERE Membership = '$Membership'";
$result = $conn->query($check);

if ($result->num_rows > 0) {
    // Update if student exists
    $sql = "UPDATE paymentdetails SET Membership='$Membership',Trainingplan='$Trainingplan',Amount='$Amount', Name='$Name',joindate='$joindate', enddate='$enddate' WHERE Membership='$Membership'";
} else {
    // Insert if student doesn't exist
    $sql = "INSERT INTO paymentdetails (Membership, Trainingplan,Amount, Name, joindate, enddate) VALUES ('$Membership', '$Trainingplan','$Amount', '$Name', '$joindate', '$enddate')";
}

if ($conn->query($sql) === TRUE) {
    echo json_encode(['success' => true, 'message' => 'Student saved successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Error: ' . $conn->error]);
}

$conn->close();
?>
