<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Access-Control-Allow-Credentials: true");
header('Content-Type: application/json');

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "gymreact";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Connection failed: ' . $conn->connect_error]));
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET['name'])) {
        $name = $_GET['name'];
        $sql = "SELECT Membership, Trainingplan, Amount, joindate, enddate, status, id FROM paymentdetails WHERE Name = '$name'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $payments = [];
            while ($row = $result->fetch_assoc()) {
                $payments[] = $row;
            }
            echo json_encode(['success' => true, 'payments' => $payments]);
        } else {
            echo json_encode(['success' => false, 'message' => 'No payment records found']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Name parameter is required']);
    }
}

$conn->close();
?>
