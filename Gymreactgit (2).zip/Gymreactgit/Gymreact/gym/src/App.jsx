import React from 'react'
import{Routes,Route} from 'react-router-dom'
import Home from './Components/Home'
import AdminLogin from './Components/Adminlogin'
import Login from './Components/Login'
import Userlogin from './Components/Userlogin'
import Admindashboard from './Components/Admindashboard'
import AddGymCourse from './Components/AddGymcourse'
import Dashboard from './Components/dashboard'
import Offlineregister from './Components/offlineregister'
import Register from './Components/Register'
import Userregister from './Components/Userregister'
import Userdashboard from './Components/Userdashboard'
import ViewRegistered from './Components/Viewregistered'
import PaymentHistory from './Components/Paymenthistory'
import Renewal from './Components/Renewal'
import UserPayments from './Components/Userpayment'
import UserRenewals from './Components/Userrenewal'

function App() {
  return (
    <Routes>
      <Route path="/" element={<Home/>}/>
      <Route path="/adminlogin" element={<AdminLogin/>}/>
      <Route path="/login" element={<Login/>}/>
      <Route path="/userlogin" element={<Userlogin />}/>
      <Route path="/admindashboard" element={<Admindashboard />}/>
      <Route path="/gymcourse" element={<AddGymCourse />}/>
      <Route path="/dash" element={<Dashboard />}/>
      <Route path="/offline" element={<Offlineregister/>}/>
      <Route path="/register" element={<Register/>}/>
      <Route path="/userregister" element={<Userregister/>}/>
      <Route path="/userdashboard" element={<Userdashboard/>}/>
      <Route path="/viewregister" element={<ViewRegistered/>}/>
      <Route path="/payment" element={<PaymentHistory/>}/>
      <Route path="/renewal" element={<Renewal/>}/>
      <Route path="/userpayment" element={<UserPayments/>}/>
      <Route path="/userrenewal" element={<UserRenewals/>}/>















    </Routes>
  )
}

export default App
