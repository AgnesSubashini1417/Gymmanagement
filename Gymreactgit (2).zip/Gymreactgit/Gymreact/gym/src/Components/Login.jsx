import React from 'react';
import { useNavigate } from 'react-router-dom';
import "../Styles/Login.css";

function Login() {
    const navigate = useNavigate();

    return (
        <div className="container">
            <div className="content">
                <h1 className="title">GYM MANAGEMENT SYSTEM</h1>
                <div className="button-container">
                    <button className="admin-btn" onClick={() => navigate("/adminlogin")}>
                        Admin
                    </button>
                    <button className="user-btn" onClick={() => navigate("/userlogin")}>
                        User
                    </button>
                </div>
            </div>
        </div>
    );
}

export default Login;
