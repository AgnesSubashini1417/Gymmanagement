import React, { useState, useEffect } from 'react';
import axios from 'axios';
import {
  Box, Grid, Card, CardContent, Typography, AppBar, Toolbar, IconButton,
  CssBaseline, List, ListItem, ListItemButton, ListItemIcon, ListItemText
} from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';
import PeopleIcon from '@mui/icons-material/People';
import PersonAddIcon from '@mui/icons-material/PersonAdd';
import LocalOfferIcon from '@mui/icons-material/LocalOffer';
import DashboardCustomizeIcon from '@mui/icons-material/DashboardCustomize';
import StreetviewIcon from '@mui/icons-material/Streetview';
import PaidIcon from '@mui/icons-material/Paid';
// import AutorenewIcon from '@mui/icons-material/Autorenew';
import GroupAddIcon from '@mui/icons-material/GroupAdd';
import ExitToAppOutlinedIcon from '@mui/icons-material/ExitToAppOutlined';
import { ExitToAppOutlined, Autorenew as AutorenewIcon, PersonOutline as PersonOutlineIcon } from '@mui/icons-material';
import { Link } from 'react-router-dom';

const sidebarWidth = 250;

const Dashboard = () => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [stats, setStats] = useState({
    totalOnlineUsers: 0,
    totalOfflineUsers: 0,
    totalOffers: 0,
  });

  useEffect(() => {
    fetchDashboardStats();
  }, []);

  const fetchDashboardStats = async () => {
    try {
      const response = await axios.get('http://localhost/gymreact/controllers/api/admin/total.php');
      setStats(response.data);
    } catch (error) {
      console.error('Error fetching dashboard stats', error);
    }
  };

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  const menuItems = [
    { text: 'Dashboard', icon: <DashboardCustomizeIcon />, route: '/admindashboard' },
    { text: 'View Registered', icon: <StreetviewIcon />, route: '/viewregister' },
    { text: 'Payment History', icon: <PaidIcon />, route: '/payment' },
    { text: 'offline Registered', icon: <PersonOutlineIcon />, route: '/offline' },

    { text: 'Renewal', icon: <AutorenewIcon />, route: '/renewal' },
    // { text: 'Add Members', icon: <GroupAddIcon />, route: '/admindashboard' }
  ];

  return (
    <>
      <CssBaseline />

      {/* Top Navbar */}
      <AppBar position="fixed" sx={{ zIndex: 1300, backgroundColor: 'white', color: 'black' }}>
        <Toolbar>
          <IconButton
            edge="start"
            onClick={handleDrawerToggle}
            sx={{ mr: 2, display: { sm: 'none' } }}
          >
            <MenuIcon />
          </IconButton>
          <Typography variant="h6" noWrap>
            Admin Dashboard
          </Typography>
        </Toolbar>
      </AppBar>

      {/* Sidebar */}
      <Box sx={{ display: 'flex' }}>
        <Box
          sx={{
            width: sidebarWidth,
            height: '100vh',
            backgroundColor: 'orange',
            color: 'white',
            position: 'fixed',
            top: 0,
            left: 0,
            pt: 8
          }}
        >
          <List>
            {menuItems.map(({ text, icon, route }) => (
              <ListItem key={text} disablePadding>
                <ListItemButton component={Link} to={route}>
                  <ListItemIcon sx={{ color: 'white' }}>{icon}</ListItemIcon>
                  <ListItemText primary={text} sx={{ color: 'white' }} />
                </ListItemButton>
              </ListItem>
            ))}
          </List>

          <div style={{ flexGrow: 1 }}></div>

          {/* Logout Button */}
          <List>
            <ListItem key="LogOut" disablePadding>
              <ListItemButton component={Link} to="/login">
                <ListItemIcon sx={{ color: 'white' }}>
                  <ExitToAppOutlinedIcon />
                </ListItemIcon>
                <ListItemText primary="LogOut" sx={{ color: 'white' }} />
              </ListItemButton>
            </ListItem>
          </List>
        </Box>

        {/* Main Content */}
        <Box component="main" sx={{ flexGrow: 1, p: 3, ml: `${sidebarWidth}px`, mt: '64px' }}>
          <Typography variant="h5" sx={{ mb: 3, fontWeight: 'bold' }}>
            Overview
          </Typography>

          <Grid container spacing={3}>
            {/* Total Online Users */}
            <Grid item xs={12} sm={4}>
              <Card sx={{ backgroundColor: '#4CAF50', color: 'white' }}>
                <CardContent>
                  <PeopleIcon sx={{ fontSize: 50 }} />
                  <Typography variant="h6" sx={{ mt: 1 }}>
                    Total Online Users
                  </Typography>
                  <Typography variant="h4" sx={{ fontWeight: 'bold' }}>{stats.totalOnlineUsers}</Typography>
                </CardContent>
              </Card>
            </Grid>

            {/* Total Offline Users */}
            <Grid item xs={12} sm={4}>
              <Card sx={{ backgroundColor: '#FF9800', color: 'white' }}>
                <CardContent>
                  <PersonAddIcon sx={{ fontSize: 50 }} />
                  <Typography variant="h6" sx={{ mt: 1 }}>
                    Total Offline Users
                  </Typography>
                  <Typography variant="h4" sx={{ fontWeight: 'bold' }}>{stats.totalOfflineUsers}</Typography>
                </CardContent>
              </Card>
            </Grid>

            {/* Total Offers */}
            <Grid item xs={12} sm={4}>
              <Card sx={{ backgroundColor: '#3F51B5', color: 'white' }}>
                <CardContent>
                  <LocalOfferIcon sx={{ fontSize: 50 }} />
                  <Typography variant="h6" sx={{ mt: 1 }}>
                    Total Offers
                  </Typography>
                  <Typography variant="h4" sx={{ fontWeight: 'bold' }}>3</Typography>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        </Box>
      </Box>
    </>
  );
};

export default Dashboard;
