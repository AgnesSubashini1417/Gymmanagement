import React, { useState } from 'react';
import { Grid } from '@mui/joy';
import EmailIcon from '@mui/icons-material/Email';
import LockIcon from '@mui/icons-material/Lock';
import { useNavigate } from 'react-router-dom';
import "../Styles/Task.css";

function AdminLogin() {
    const [credentials, setCredentials] = useState({
        name: "",
        password: "",
    });

    const [errors, setErrors] = useState({
        name: "",
        password: "",
        server: "",
    });

    const navigate = useNavigate();

    const handleChange = (event) => {
        const { id, value } = event.target;
        setCredentials((prevState) => ({
            ...prevState,
            [id]: value,
        }));
    };

    const validate = () => {
        let isValid = true;
        let validationErrors = {};

        if (!credentials.name) {
            isValid = false;
            validationErrors.name = "Email is required";
        } else if (!/\S+@\S+\.\S+/.test(credentials.name)) {
            isValid = false;
            validationErrors.name = "Email is invalid";
        }

        if (!credentials.password) {
            isValid = false;
            validationErrors.password = "Password is required";
        }

        setErrors(validationErrors);
        return isValid;
    };

    const handleSubmit = (event) => {
        event.preventDefault();

        if (validate()) {
            if (credentials.name === "admin@gmail.com" && credentials.password === "admin") {
                navigate('/admindashboard');
            } else {
                setErrors((prevErrors) => ({
                    ...prevErrors,
                    server: "Invalid login credentials.",
                }));
            }
        }
    };

    return (
        <Grid container spacing={2} sx={{ flexGrow: 1 }}>
            <Grid item xs={12}>
                <div className="container">
                    <div className="har">
                        <div className="z">
                            <div className="circle"></div>
                            <div className="divider"></div>
                            <div className="gym-name">GYM MANAGEMENT SYSTEM</div>
                        </div>

                        <h1>Login</h1>
                        <form onSubmit={handleSubmit}>
                            <div className="inputcont">
                                <EmailIcon className="input-icons" />
                                <input
                                    type="text"
                                    className="input-padding"
                                    placeholder="Email"
                                    id="name"
                                    value={credentials.name}
                                    onChange={handleChange}
                                />
                                {errors.name && <p className="error">{errors.name}</p>}
                            </div>

                            <div className="inputcont">
                                <LockIcon className="input-icons" />
                                <input
                                    type="password"
                                    className="input-padding"
                                    placeholder="Password"
                                    id="password"
                                    value={credentials.password}
                                    onChange={handleChange}
                                />
                                {errors.password && <p className="error">{errors.password}</p>}
                            </div>

                            {errors.server && <p className="error">{errors.server}</p>}

                            <div>
                                <button type="submit">LOGIN</button>
                            </div>
                        </form>
                    </div>
                </div>
            </Grid>
        </Grid>
    );
}

export default AdminLogin;
