import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import {
  AppBar,
  Toolbar,
  Typography,
  IconButton,
  Drawer,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Box,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Button,
} from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";
import DashboardCustomizeIcon from "@mui/icons-material/DashboardCustomize";
import StreetviewIcon from "@mui/icons-material/Streetview";
import PaidIcon from "@mui/icons-material/Paid";
import AutorenewIcon from "@mui/icons-material/Autorenew";
import PersonOutlineIcon from "@mui/icons-material/PersonOutline";
import ExitToAppOutlined from "@mui/icons-material/ExitToAppOutlined";

const drawerWidth = 230;

const Renewal = () => {
  const navigate = useNavigate();
  const [renewals, setRenewals] = useState([]);

  useEffect(() => {
    fetchRenewals();
  }, []);

  const fetchRenewals = async () => {
    try {
      const response = await axios.get("http://localhost/gymreact/controllers/api/admin/viewrenewal.php");
      if (response.data.success) {
        const updatedRenewals = response.data.renewals.map((renewal) => ({
          ...renewal,
          status: localStorage.getItem(`renewal_${renewal.id}`) || "Pending",
        }));
        setRenewals(updatedRenewals);
      } else {
        alert("No renewal records found!");
      }
    } catch (error) {
      console.error("Error fetching renewals:", error);
      alert("An error occurred while fetching renewals.");
    }
  };

  const handleRenew = async (id) => {
    try {
      const response = await axios.post("http://localhost/gymreact/controllers/api/User/renewMembership.php", { id });
      if (response.data.success) {
        alert("Renewal successful!");
        localStorage.setItem(`renewal_${id}`, "Accepted");
        setRenewals((prevRenewals) =>
          prevRenewals.map((renewal) => (renewal.id === id ? { ...renewal, status: "Accepted" } : renewal))
        );
      } else {
        alert("Renewal failed!");
      }
    } catch (error) {
      console.error("Error processing renewal:", error);
      alert("An error occurred while processing renewal.");
    }
  };

  const menuItems = [
    { text: "Dashboard", icon: <DashboardCustomizeIcon />, route: "/dash" },
    { text: "View Registered", icon: <StreetviewIcon />, route: "/viewregister" },
    { text: "Payment History", icon: <PaidIcon />, route: "/payment" },
    { text: "Offline Registered", icon: <PersonOutlineIcon />, route: "/offline" },
    { text: "Renewal", icon: <AutorenewIcon />, route: "/renewal" },
  ];

  return (
    <>
      <AppBar position="fixed" sx={{ zIndex: 1200, backgroundColor: "white", color: "black" }}>
        <Toolbar>
          <IconButton edge="start" sx={{ mr: 2 }}>
            <MenuIcon />
          </IconButton>
          <Typography variant="h6" noWrap>
            Admin Dashboard
          </Typography>
        </Toolbar>
      </AppBar>

      <Box sx={{ display: "flex", marginTop: "64px" }}>
        <Drawer
          variant="permanent"
          sx={{
            width: drawerWidth,
            flexShrink: 0,
            "& .MuiDrawer-paper": { width: drawerWidth, backgroundColor: "red", marginTop: "64px" },
          }}
        >
          <List>
            {menuItems.map(({ text, icon, route }) => (
              <ListItem key={text} disablePadding>
                <ListItemButton onClick={() => navigate(route)}>
                  <ListItemIcon style={{ color: "white" }}>{icon}</ListItemIcon>
                  <ListItemText primary={text} style={{ color: "white" }} />
                </ListItemButton>
              </ListItem>
            ))}
            <ListItem disablePadding>
              <ListItemButton onClick={() => navigate("/logout")}>  
                <ListItemIcon>
                  <ExitToAppOutlined style={{ color: "white" }} />
                </ListItemIcon>
                <ListItemText primary="LogOut" style={{ color: "white" }} />
              </ListItemButton>
            </ListItem>
          </List>
        </Drawer>

        <Box component="main" sx={{ flexGrow: 1, p: 3 }}>
          <Typography variant="h5" gutterBottom style={{ fontWeight: "bold" }}>
            Membership Renewal Table
          </Typography>
          <TableContainer component={Paper} style={{ marginTop: "20px" }}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell><strong>Name</strong></TableCell>
                  <TableCell><strong>Membership</strong></TableCell>
                  <TableCell><strong>Renewal Date</strong></TableCell>
                  <TableCell><strong>Amount</strong></TableCell>
                  <TableCell><strong>Status</strong></TableCell>
                  <TableCell><strong>Action</strong></TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {renewals.map((renewal) => (
                  <TableRow key={renewal.id}>
                    <TableCell>{renewal.Name}</TableCell>
                    <TableCell>{renewal.Membership}</TableCell>
                    <TableCell>{renewal.enddate}</TableCell>
                    <TableCell>{renewal.Amount}</TableCell>
                    <TableCell>{renewal.status}</TableCell>
                    <TableCell>
                      {renewal.status === "Accepted" ? (
                        <Button variant="contained" color="success" disabled>
                          Accepted
                        </Button>
                      ) : (
                        <Button variant="contained" color="primary" onClick={() => handleRenew(renewal.id)}>
                          Renew Now
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      </Box>
    </>
  );
};

export default Renewal;
