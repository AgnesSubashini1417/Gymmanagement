import React, { useEffect, useState } from "react";
import axios from "axios";
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, AppBar, Toolbar, Typography, Box, Drawer, List, ListItem, ListItemButton, ListItemIcon, ListItemText } from "@mui/material";
import DashboardCustomizeIcon from "@mui/icons-material/DashboardCustomize";
import StreetviewIcon from "@mui/icons-material/Streetview";
import PaidIcon from "@mui/icons-material/Paid";
import AutorenewIcon from "@mui/icons-material/Autorenew";
import PersonOutlineIcon from "@mui/icons-material/PersonOutline";
import GroupAddIcon from "@mui/icons-material/GroupAdd";
import ExitToAppOutlined from "@mui/icons-material/ExitToAppOutlined";
import { useNavigate } from "react-router-dom";

const drawerWidth = 230;

const ViewRegistered = () => {
  const navigate = useNavigate();
  const [registeredUsers, setRegisteredUsers] = useState([]);

  useEffect(() => {
    // Fetch user data from the backend
    axios.get("http://localhost/gymreact/controllers/api/admin/viewregister.php")
      .then(response => {
        if (response.data.success) {
          setRegisteredUsers(response.data.users);
        } else {
          console.error("Failed to fetch users:", response.data.message);
        }
      })
      .catch(error => {
        console.error("Error fetching users:", error);
      });
  }, []);

  const menuItems = [
    { text: "Dashboard", icon: <DashboardCustomizeIcon />, route: "/dash" },
    { text: "View Registered", icon: <StreetviewIcon />, route: "/admindashboard" },
    { text: "Payment History", icon: <PaidIcon />, route: "/payment" },
    { text: "Offline Registered", icon: <PersonOutlineIcon />, route: "/offline" },
    { text: "Renewal", icon: <AutorenewIcon />, route: "/renewal" },
    // { text: "Add Members", icon: <GroupAddIcon />, route: "/gymcourse" },
  ];

  return (
    <>
      <AppBar position="fixed" style={{ zIndex: 1200, color: "black", backgroundColor: "white" }}>
        <Toolbar>
          <Typography variant="h6" noWrap component="div">
            Gym Management System
          </Typography>
        </Toolbar>
      </AppBar>

      <Box sx={{ display: "flex", marginTop: "64px" }}>
        <Drawer
          variant="permanent"
          sx={{
            width: drawerWidth,
            flexShrink: 0,
            "& .MuiDrawer-paper": { width: drawerWidth, backgroundColor: "red", marginTop: "64px" },
          }}
        >
          <List>
            {menuItems.map(({ text, icon, route }) => (
              <ListItem key={text} disablePadding>
                <ListItemButton onClick={() => navigate(route)}>
                  <ListItemIcon style={{ color: "white" }}>{icon}</ListItemIcon>
                  <ListItemText primary={text} style={{ color: "white" }} />
                </ListItemButton>
              </ListItem>
            ))}
            <ListItem key="LogOut" disablePadding>
              <ListItemButton onClick={() => navigate("/login")}>
                <ListItemIcon>
                  <ExitToAppOutlined style={{ color: "white" }} />
                </ListItemIcon>
                <ListItemText primary="LogOut" style={{ color: "white" }} />
              </ListItemButton>
            </ListItem>
          </List>
        </Drawer>

        <Box component="main" sx={{ flexGrow: 1, p: 3 }}>
          <Typography variant="h5" gutterBottom style={{ fontWeight: "bold" }}>
            User Details
          </Typography>
          <TableContainer component={Paper} style={{ marginTop: "20px" }}>
            <Table>
              <TableHead>
                <TableRow style={{ backgroundColor: "#f0f0f0" }}>
                  <TableCell><strong>Name</strong></TableCell>
                  <TableCell><strong>Age</strong></TableCell>
                  <TableCell><strong>Email</strong></TableCell>
                  <TableCell><strong>Gender</strong></TableCell>
                  <TableCell><strong>Phone</strong></TableCell>
                  <TableCell><strong>Address</strong></TableCell>
                  <TableCell><strong>City</strong></TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {registeredUsers.length > 0 ? (
                  registeredUsers.map((user, index) => (
                    <TableRow key={index}>
                      <TableCell>{user.name}</TableCell>
                      <TableCell>{user.age}</TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>{user.gender}</TableCell>
                      <TableCell>{user.phone}</TableCell>
                      <TableCell>{user.Address}</TableCell>
                      <TableCell>{user.city}</TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={7} style={{ textAlign: "center" }}>
                      No registered users found.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      </Box>
    </>
  );
};

export default ViewRegistered;
