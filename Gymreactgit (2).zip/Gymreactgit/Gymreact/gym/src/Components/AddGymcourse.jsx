import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import gymCourseImage from '../assets/ghym2.png';
import { FaEdit } from 'react-icons/fa';
import Drawer from '@mui/material/Drawer';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import DashboardCustomizeIcon from '@mui/icons-material/DashboardCustomize';
import StreetviewIcon from '@mui/icons-material/Streetview';
import PaidIcon from '@mui/icons-material/Paid';
import AutorenewIcon from '@mui/icons-material/Autorenew';
import GroupAddIcon from '@mui/icons-material/GroupAdd';
import ExitToAppOutlined from '@mui/icons-material/ExitToAppOutlined';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';
import MenuIcon from '@mui/icons-material/Menu';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import './AddGymcourse.css';

const drawerWidth = 230;

const AddGymCourse = () => {
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  const menuItems = [
    { text: 'Dashboard', icon: <DashboardCustomizeIcon />, route: '/dashboard' },
    { text: 'View Registered', icon: <StreetviewIcon />, route: '/dashboard5' },
    { text: 'Payment History', icon: <PaidIcon />, route: '/paymenthistory' },
    { text: 'Renewal', icon: <AutorenewIcon />, route: '/renewal' },
    { text: 'Add Members', icon: <GroupAddIcon />, route: '/admindashboard' }
  ];

  const drawer = (
    <div style={{ display: 'flex', flexDirection: 'column', height: '90%' }}>
      <List>
        {menuItems.map(({ text, icon, route }) => (
          <ListItem key={text} disablePadding>
            <ListItemButton component={Link} to={route}>
              <ListItemIcon style={{ color: 'white' }}>{icon}</ListItemIcon>
              <ListItemText primary={text} style={{ color: 'white' }} />
            </ListItemButton>
          </ListItem>
        ))}
      </List>
      <div style={{ flexGrow: 1 }}></div>
      <List>
        <ListItem key="LogOut" disablePadding>
          <ListItemButton component={Link} to="/logout">
            <ListItemIcon>
              <ExitToAppOutlined style={{ color: 'white' }} />
            </ListItemIcon>
            <ListItemText primary="LogOut" style={{ color: 'white' }} />
          </ListItemButton>
        </ListItem>
      </List>
    </div>
  );

  return (
    <>
      {/* Navbar */}
      <AppBar position="fixed" style={{ zIndex: 1200, color: 'black', backgroundColor: 'white' }}>
        <Toolbar>
          <IconButton
            aria-label="open drawer"
            edge="start"
            onClick={handleDrawerToggle}
            sx={{ mr: 2, display: { sm: 'none' } }}
          >
            <MenuIcon />
          </IconButton>
          <Typography variant="h6" noWrap component="div">
            Gym Membership
          </Typography>
        </Toolbar>
      </AppBar>

      <Box sx={{ display: 'flex', marginTop: '64px' }}>
        {/* Sidebar for Large Screens */}
        <Drawer
          variant="permanent"
          sx={{
            display: { xs: 'none', sm: 'block' },
            '& .MuiDrawer-paper': { boxSizing: 'border-box', width: drawerWidth, backgroundColor: 'red', marginTop: '64px' },
          }}
          open
        >
          {drawer}
        </Drawer>

        {/* Sidebar for Small Screens */}
        <Drawer
          variant="temporary"
          open={mobileOpen}
          onClose={handleDrawerToggle}
          sx={{
            display: { xs: 'block', sm: 'none' },
            '& .MuiDrawer-paper': { boxSizing: 'border-box', width: drawerWidth, backgroundColor: '#f0f0f0' },
          }}
        >
          {drawer}
        </Drawer>

        {/* Gym Course Cards Section */}
        <Box component="main" sx={{ flexGrow: 1, padding: '20px', ml: { sm: `${drawerWidth}px` } }}>
          <Grid container spacing={2} justifyContent="center">
            {/* Course 1 - 3 Months */}
            <Grid item xs={12} sm={4}>
              <div className="card">
                <img src={gymCourseImage} alt="Gym Course" />
                <p className="course-title">3-Month Gym Membership</p>
                <p className="course-desc">Full Body Training</p>
                <p className="course-price">₹3000</p>
                {/* <Link to={'/edit-course/3-months'} className="no-underline">
                  <button className="edit-button" aria-label="Edit Course">
                    Edit <FaEdit />
                  </button>
                </Link> */}
              </div>
            </Grid>

            {/* Course 2 - 6 Months */}
            <Grid item xs={12} sm={4}>
              <div className="card">
                <img src={gymCourseImage} alt="Gym Course" />
                <p className="course-title">6-Month Gym Membership</p>
                <p className="course-desc">Strength & Conditioning</p>
                <p className="course-price">₹6000</p>
                {/* <Link to={'/edit-course/6-months'} className="no-underline">
                  <button className="edit-button" aria-label="Edit Course">
                    Edit <FaEdit />
                  </button>
                </Link> */}
              </div>
            </Grid>

            {/* Course 3 - 1 Year */}
            <Grid item xs={12} sm={4}>
              <div className="card">
                <img src={gymCourseImage} alt="Gym Course" />
                <p className="course-title">1-Year Gym Membership</p>
                <p className="course-desc">Pro Athlete Plan</p>
                <p className="course-price">₹15000</p>
                {/* <Link to={'/edit-course/1-year'} className="no-underline">
                  <button className="edit-button" aria-label="Edit Course">
                    Edit <FaEdit />
                  </button>
                </Link> */}
              </div>
            </Grid>
          </Grid>
        </Box>
      </Box>
    </>
  );
};

export default AddGymCourse;
