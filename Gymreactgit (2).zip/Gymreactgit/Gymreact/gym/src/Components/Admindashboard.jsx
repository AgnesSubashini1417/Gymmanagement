import React, { useState } from 'react';
import PropTypes from 'prop-types';
import Drawer from '@mui/material/Drawer';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import DashboardCustomizeIcon from '@mui/icons-material/DashboardCustomize';
import StreetviewIcon from '@mui/icons-material/Streetview';
import PaidIcon from '@mui/icons-material/Paid';
import Button from '@mui/material/Button';
import Grid from '@mui/material/Grid';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';
import MenuIcon from '@mui/icons-material/Menu';
import Box from '@mui/material/Box';
import { ExitToAppOutlined, Autorenew as AutorenewIcon, PersonOutline as PersonOutlineIcon } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';

const drawerWidth = 230;

const Admindashboard = (props) => {
  const { window } = props;
  const [mobileOpen, setMobileOpen] = useState(false);
  const navigate = useNavigate();

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  const handleNavigation = (route) => {
    navigate(route);
  };

  const menuItems = [
    { text: 'Dashboard', icon: <DashboardCustomizeIcon />, route: '/dash' },
    { text: 'View Registered', icon: <StreetviewIcon />, route: '/viewregister' },
    { text: 'Payment History', icon: <PaidIcon />, route: '/payment' },
    { text: 'Offline Registered', icon: <PersonOutlineIcon />, route: '/offline' },
    { text: 'Renewal', icon: <AutorenewIcon />, route: '/renewal' },
  ];

  const drawer = (
    <div style={{ display: 'flex', flexDirection: 'column', height: '90%' }}>
      <List>
        {menuItems.map(({ text, icon, route }) => (
          <ListItem key={text} disablePadding>
            <ListItemButton onClick={() => handleNavigation(route)}>
              <ListItemIcon style={{ color: 'white' }}>{icon}</ListItemIcon>
              <ListItemText primary={text} style={{ color: 'white' }} />
            </ListItemButton>
          </ListItem>
        ))}
      </List>
      <div style={{ flexGrow: 1 }}></div>
      <List>
        <ListItem key="LogOut" disablePadding>
          <ListItemButton onClick={() => handleNavigation('/login')}>
            <ListItemIcon>
              <ExitToAppOutlined style={{ color: 'white' }} />
            </ListItemIcon>
            <ListItemText primary="LogOut" style={{ color: 'white' }} />
          </ListItemButton>
        </ListItem>
      </List>
    </div>
  );

  const container = window !== undefined ? () => window().document.body : undefined;

  return (
    <>
      <AppBar position="fixed" style={{ zIndex: 1200, color: 'black', backgroundColor: 'white' }}>
        <Toolbar>
          <IconButton
            aria-label="open drawer"
            edge="start"
            onClick={handleDrawerToggle}
            sx={{ mr: 2, display: { sm: 'none' } }}
          >
            <MenuIcon />
          </IconButton>
          <Typography variant="h6" noWrap component="div">
            Gym Management System
          </Typography>
        </Toolbar>
      </AppBar>
      <Box sx={{ display: 'flex', marginTop: '64px' }}>
        <Drawer
          container={container}
          variant="temporary"
          open={mobileOpen}
          onClose={handleDrawerToggle}
          ModalProps={{
            keepMounted: true,
          }}
          sx={{
            display: { xs: 'block', sm: 'none' },
            '& .MuiDrawer-paper': { boxSizing: 'border-box', width: drawerWidth, backgroundColor: '#f0f0f0' },
          }}
        >
          {drawer}
        </Drawer>
        <Drawer
          variant="permanent"
          sx={{
            display: { xs: 'none', sm: 'block' },
            '& .MuiDrawer-paper': { boxSizing: 'border-box', width: drawerWidth, backgroundColor: 'red', marginTop: '64px' },
          }}
          open
        >
          {drawer}
        </Drawer>
        <Box component="main" sx={{ flexGrow: 1 }}>
          <Grid container spacing={2} justifyContent="center" flexDirection="row">
            <Grid item xs={12} sm={8} style={{ textAlign: 'center', marginTop: '20px' }}>
              <Typography variant="h4" component="h1" style={{ fontWeight: 'bold' }}>
                Welcome to Gym Management System
              </Typography>
            </Grid>
          </Grid>
        </Box>
      </Box>
    </>
  );
};

Admindashboard.propTypes = {
  window: PropTypes.func,
};

export default Admindashboard;
