import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import {
  AppBar,
  Toolbar,
  Typography,
  IconButton,
  Box,
  Grid,
  Card,
  CardContent,
  Button,
  TextField,
  MenuItem,
} from "@mui/material";
import { ArrowBack as ArrowBackIcon, Menu as MenuIcon } from "@mui/icons-material";

const UserRegister = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: "",
    age: "",
    gender: "",
    email: "",
    password: "",
    phone: "",
    Address: "",
    city: "",
  });

  // Handle Input Change
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  // Handle Form Submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(
        "http://localhost/gymreact/controllers/api/User/register.php",
        formData,
        { headers: { "Content-Type": "application/json" } }
      );

      if (response.data.success) {
        alert("Registration Successful!");
        setFormData({
          name: "",
          age: "",
          gender: "",
          email: "",
          password: "",
          phone: "",
          Address: "",
          city: "",
        });
      } else {
        alert(response.data.message);
      }
    } catch (error) {
      console.error("Error submitting form:", error);
      alert("Registration failed. Please try again.");
    }
  };

  return (
    <>
      {/* Navbar */}
      <AppBar position="fixed" sx={{ backgroundColor: "white", color: "black" }}>
        <Toolbar>
          <IconButton edge="start" sx={{ mr: 2, display: { sm: "none" } }}>
            <MenuIcon />
          </IconButton>
          <Typography variant="h6">Gym Management System</Typography>
        </Toolbar>
      </AppBar>

      {/* Background Wrapper */}
      <Box
        sx={{
          minHeight: "100vh",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          p: 3,
          backgroundColor: "#f5f5f5",
        }}
      >
        <Grid container spacing={2} maxWidth="500px">
          <Grid item xs={12}>
            <Card sx={{ p: 3, boxShadow: 5, borderRadius: 3 }}>
              <CardContent>
                <Typography variant="h5" sx={{ fontWeight: "bold", textAlign: "center", mb: 2 }}>
                  New Member Registration
                </Typography>

                <form onSubmit={handleSubmit}>
                  <TextField fullWidth margin="normal" label="Name" name="name" value={formData.name} onChange={handleInputChange} required />
                  <TextField fullWidth margin="normal" label="Age" name="age" type="number" value={formData.age} onChange={handleInputChange} required />
                  
                  <TextField fullWidth margin="normal" select label="Gender" name="gender" value={formData.gender} onChange={handleInputChange} required>
                    <MenuItem value="Male">Male</MenuItem>
                    <MenuItem value="Female">Female</MenuItem>
                    <MenuItem value="Other">Other</MenuItem>
                  </TextField>

                  <TextField fullWidth margin="normal" label="Email" name="email" type="email" value={formData.email} onChange={handleInputChange} required />
                  <TextField fullWidth margin="normal" label="Password" name="password" type="password" value={formData.password} onChange={handleInputChange} required />
                  <TextField fullWidth margin="normal" label="Phone" name="phone" type="tel" value={formData.phone} onChange={handleInputChange} required />
                  <TextField fullWidth margin="normal" label="Address" name="Address" value={formData.Address} onChange={handleInputChange} required />
                  <TextField fullWidth margin="normal" label="City" name="city" value={formData.city} onChange={handleInputChange} required />

                  <Button fullWidth variant="contained" sx={{ mt: 2, p: 1.5 }} type="submit">
                    Register
                  </Button>
                  <Button fullWidth variant="outlined" sx={{ mt: 2, p: 1.5 }} startIcon={<ArrowBackIcon />} onClick={() => navigate("/login")}>
                    Back to Login
                  </Button>
                </form>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      </Box>
    </>
  );
};

export default UserRegister;
