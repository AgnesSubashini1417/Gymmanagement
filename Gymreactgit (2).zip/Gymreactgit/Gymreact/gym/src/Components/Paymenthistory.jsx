import React, { useEffect, useState } from "react";
import axios from "axios";
import {
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper,
  Button, Typography, Box, AppBar, Toolbar, Drawer, List, ListItem,
  ListItemButton, ListItemIcon, ListItemText
} from "@mui/material";
import DashboardCustomizeIcon from "@mui/icons-material/DashboardCustomize";
import StreetviewIcon from "@mui/icons-material/Streetview";
import PaidIcon from "@mui/icons-material/Paid";
import { ExitToAppOutlined } from "@mui/icons-material";
import { useNavigate } from "react-router-dom";
import {  Autorenew as AutorenewIcon, PersonOutline as PersonOutlineIcon } from '@mui/icons-material';

const drawerWidth = 230;

const PaymentHistory = () => {
  const navigate = useNavigate();
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchPayments();
  }, []);

  const fetchPayments = async () => {
    try {
      const response = await axios.get("http://localhost/gymreact/controllers/api/admin/paymentdetails.php");
      if (response.data.success) {
        setPayments(response.data.payments);
      } else {
        alert(response.data.message);
      }
    } catch (error) {
      console.error("Error fetching payments:", error);
      alert("Failed to fetch payment records");
    } finally {
      setLoading(false);
    }
  };

  const handleAcceptPayment = async (id) => {
    try {
      const response = await axios.post("http://localhost/gymreact/controllers/api/admin/paymentdetails.php", { id });
      if (response.data.success) {
        setPayments((prevPayments) =>
          prevPayments.map((payment) =>
            payment.id === id ? { ...payment, status: "Accepted" } : payment
          )
        );
      } else {
        alert("Failed to accept payment");
      }
    } catch (error) {
      console.error("Error updating payment:", error);
      alert("An error occurred while accepting payment");
    }
  };

  return (
    <>
      <AppBar position="fixed" style={{ zIndex: 1200, color: "black", backgroundColor: "white" }}>
        <Toolbar>
          <Typography variant="h6" noWrap>
            Admin Dashboard
          </Typography>
        </Toolbar>
      </AppBar>

      <Box sx={{ display: "flex", marginTop: "64px" }}>
        <Drawer
          variant="permanent"
          sx={{
            width: drawerWidth,
            flexShrink: 0,
            "& .MuiDrawer-paper": { width: drawerWidth, backgroundColor: "red", marginTop: "64px" },
          }}
        >
          <List>
            <ListItem disablePadding>
              <ListItemButton onClick={() => navigate("/dash")}>
                <ListItemIcon style={{ color: "white" }}>
                  <DashboardCustomizeIcon />
                </ListItemIcon>
                <ListItemText primary="Dashboard" style={{ color: "white" }} />
              </ListItemButton>
            </ListItem>
            <ListItem disablePadding>
              <ListItemButton onClick={() => navigate("/viewregister")}>
                <ListItemIcon style={{ color: "white" }}>
                  <StreetviewIcon />
                </ListItemIcon>
                <ListItemText primary="View Registered" style={{ color: "white" }} />
              </ListItemButton>
            </ListItem>
            <ListItem disablePadding>
              <ListItemButton onClick={() => navigate("/admindashboard")}>
                <ListItemIcon style={{ color: "white" }}>
                  <PaidIcon />
                </ListItemIcon>
                <ListItemText primary="Payment History" style={{ color: "white" }} />
              </ListItemButton>
            </ListItem>
            <ListItem disablePadding>
              <ListItemButton onClick={() => navigate("/offline")}>
                <ListItemIcon style={{ color: "white" }}>
                <PersonOutlineIcon />
                </ListItemIcon>
                <ListItemText primary="offlineregister" style={{ color: "white" }} />
              </ListItemButton>
            </ListItem>
            <ListItem disablePadding>
              <ListItemButton onClick={() => navigate("/paymenthistory")}>
                <ListItemIcon style={{ color: "white" }}>
                <AutorenewIcon />
                </ListItemIcon>
                <ListItemText primary="Renewal" style={{ color: "white" }} />
              </ListItemButton>
            </ListItem>
            <ListItem disablePadding>
              <ListItemButton onClick={() => navigate("/logout")}>
                <ListItemIcon>
                  <ExitToAppOutlined style={{ color: "white" }} />
                </ListItemIcon>
                <ListItemText primary="LogOut" style={{ color: "white" }} />
              </ListItemButton>
            </ListItem>
          </List>
        </Drawer>

        <Box component="main" sx={{ flexGrow: 1, p: 3 }}>
          <Typography variant="h5" gutterBottom style={{ fontWeight: "bold" }}>
            Payment History
          </Typography>

          {loading ? (
            <Typography>Loading...</Typography>
          ) : (
            <TableContainer component={Paper} style={{ marginTop: "20px" }}>
              <Table>
                <TableHead>
                  <TableRow style={{ backgroundColor: "#f0f0f0" }}>
                    <TableCell><strong>Name</strong></TableCell>
                    <TableCell><strong>Membership</strong></TableCell>
                    <TableCell><strong>Training Plan</strong></TableCell>
                    <TableCell><strong>Amount</strong></TableCell>
                    <TableCell><strong>Joining Date</strong></TableCell>
                    <TableCell><strong>Ending Date</strong></TableCell>
                    <TableCell><strong>Status</strong></TableCell>
                    <TableCell><strong>Action</strong></TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {payments.length > 0 ? (
                    payments.map((payment) => (
                      <TableRow key={payment.id}>
                        <TableCell>{payment.Name}</TableCell>
                        <TableCell>{payment.Membership}</TableCell>
                        <TableCell>{payment.Trainingplan}</TableCell>
                        <TableCell>${payment.Amount}</TableCell>
                        <TableCell>{payment.joindate}</TableCell>
                        <TableCell>{payment.enddate}</TableCell>
                        <TableCell>{payment.status || "Pending"}</TableCell>
                        <TableCell>
                          {payment.status === "Accepted" ? (
                            <Button variant="contained" color="secondary" disabled>
                              Accepted
                            </Button>
                          ) : (
                            <Button
                              variant="contained"
                              color="success"
                              onClick={() => handleAcceptPayment(payment.id)}
                            >
                              Accept
                            </Button>
                          )}
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={8} style={{ textAlign: "center" }}>
                        No payment records found.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </Box>
      </Box>
    </>
  );
};

export default PaymentHistory;
