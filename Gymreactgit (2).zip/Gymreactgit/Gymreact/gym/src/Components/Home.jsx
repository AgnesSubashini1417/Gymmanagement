import React from 'react';
import { styled } from '@mui/joy/styles';
import FacebookIcon from '@mui/icons-material/Facebook';
import GoogleIcon from '@mui/icons-material/Google';
import InstagramIcon from '@mui/icons-material/Instagram';
import WhatsAppIcon from '@mui/icons-material/WhatsApp';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import { useNavigate } from 'react-router-dom';
import img from "../assets/ghy1.png"; // Import your image

// Fullscreen Background Image
const ImageContainer = styled('div')({
  position: 'fixed', // Ensures the image is always in place
  width: '100vw',
  height: '100vh',
  top: 0,
  left: 0,
  zIndex: -1, // Send it behind other content
  overflow: 'hidden',
});

// Image Styling
const FullScreenImage = styled('img')({
  width: '100%',
  height: '100%',
//   objectFit: 'cover', // Ensures it fills the screen without stretching
  position: 'absolute',
  top: 0, // Adjust this value to move image down
  left: 0,
});

// Centered Content
const ContentContainer = styled('div')({
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  textAlign: 'center',
  color: 'white',
});

// Social Media Icons
const OverlayIcon = styled('div')({
  position: 'absolute',
  bottom: '20px',
  left: '50%',
  transform: 'translateX(-50%)',
  display: 'flex',
  gap: '20px',
  alignItems: 'center',
  justifyContent: 'center',
  flexWrap: 'wrap',
});

export default function Home() {
  const navigate = useNavigate();

  const handleGetStarted = () => {
    navigate('/login');
  };

  return (
    <>
      {/* Background Image */}
      <ImageContainer>
        <FullScreenImage src={img} alt="Gym Background" />
      </ImageContainer>

      {/* Main Content */}
      <ContentContainer>
        <Typography variant="h2" sx={{ fontWeight: 'bold' }}>
          Get Ready
        </Typography>
        <Typography variant="h6" sx={{ fontStyle: 'italic' }}>
          Shape your body
        </Typography>
        <Typography variant="h6" sx={{ marginTop: '40px', fontSize: '1rem', maxWidth: '600px', margin: '0 auto' }}>
          "The harder you work and the more prepared you are for something, you're going to be able to persevere through anything."
        </Typography>

        <Button
          variant="contained"
          sx={{
            backgroundColor: 'red',
            marginTop: '20px',
            color: 'white',
            borderRadius: '20px',
            padding: '10px 20px',
            fontSize: '1rem',
            '&:hover': {
              backgroundColor: 'darkred',
            },
          }}
          onClick={handleGetStarted}
        >
          Get Started
        </Button>
      </ContentContainer>

      {/* Social Media Icons */}
      <OverlayIcon>
        <FacebookIcon sx={{ backgroundColor: 'white', borderRadius: '50%', color: 'red', padding: '5px' }} />
        <GoogleIcon sx={{ backgroundColor: 'white', borderRadius: '50%', color: 'red', padding: '5px' }} />
        <InstagramIcon sx={{ backgroundColor: 'white', borderRadius: '50%', color: 'red', padding: '5px' }} />
        <WhatsAppIcon sx={{ backgroundColor: 'white', borderRadius: '50%', color: 'red', padding: '5px' }} />
      </OverlayIcon>
    </>
  );
}
