import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Box,
} from "@mui/material";

const UserPayments = () => {
  const navigate = useNavigate();
  const userName = sessionStorage.getItem("userName");

  const [payments, setPayments] = useState([]);

  useEffect(() => {
    fetchPayments();
  }, []);

  const fetchPayments = async () => {
    try {
      const response = await axios.get(
        `http://localhost/gymreact/controllers/api/User/viewpayments.php?name=${userName}`
      );
      if (response.data.success) {
        setPayments(response.data.payments);
      } else {
        alert("No payment records found!");
      }
    } catch (error) {
      console.error("Error fetching payments:", error);
      alert("An error occurred while fetching payments.");
    }
  };

  return (
    <div>
      <AppBar position="static">
        <Toolbar>
          <Typography variant="h6">Payment History</Typography>
          <Box sx={{ flexGrow: 1 }} />
          <Button color="inherit" onClick={() => navigate("/userdashboard")}>
            Back
          </Button>
        </Toolbar>
      </AppBar>

      <TableContainer component={Paper} style={{ marginTop: 20, width: "90%", margin: "auto" }}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell><strong>Membership</strong></TableCell>
              <TableCell><strong>Training Plan</strong></TableCell>
              <TableCell><strong>Amount (₹)</strong></TableCell>
              <TableCell><strong>Join Date</strong></TableCell>
              <TableCell><strong>End Date</strong></TableCell>
              <TableCell><strong>Action</strong></TableCell> 
            </TableRow>
          </TableHead>
          <TableBody>
            {payments.length > 0 ? (
              payments.map((payment, index) => (
                <TableRow key={index}>
                  <TableCell>{payment.Membership}</TableCell>
                  <TableCell>{payment.Trainingplan}</TableCell>
                  <TableCell>{payment.Amount}</TableCell>
                  <TableCell>{payment.joindate}</TableCell>
                  <TableCell>{payment.enddate}</TableCell>
                
                  <TableCell>
  {payment.status === "Accepted" ? (
  <Button variant="contained" style={{ backgroundColor: "green", color: "white" }} disabled>
  Accepted
</Button>

 
  ) : (
    <Button variant="contained" color="primary">
      Request Renewal
    </Button>
  )}
</TableCell>

                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={6} style={{ textAlign: "center" }}>
                  No payment records found.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>
    </div>
  );
};

export default UserPayments;
