import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { useNavigate } from 'react-router-dom';
import {
  AppBar, Toolbar, Typography, IconButton, Drawer, List, ListItem, ListItemButton,
  ListItemIcon, ListItemText, Box, Grid, Card, CardContent, Button
} from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';
import DashboardCustomizeIcon from '@mui/icons-material/DashboardCustomize';
import StreetviewIcon from '@mui/icons-material/Streetview';
import PaidIcon from '@mui/icons-material/Paid';
import AutorenewIcon from '@mui/icons-material/Autorenew';
import GroupAddIcon from '@mui/icons-material/GroupAdd';
import PersonAddIcon from '@mui/icons-material/PersonAdd';
import PersonOutlineIcon from '@mui/icons-material/PersonOutline';


import ExitToAppOutlined from '@mui/icons-material/ExitToAppOutlined';

const drawerWidth = 250;

const OfflineRegister = (props) => {  // Renamed component to start with an uppercase letter
  const { window } = props;
  const [mobileOpen, setMobileOpen] = useState(false);
  const navigate = useNavigate();

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  const handleNavigation = (route) => {
    navigate(route);
  };

  const menuItems = [
    { text: 'Dashboard', icon: <DashboardCustomizeIcon />, route: '/dash' },
    { text: 'View Registered', icon: <StreetviewIcon />, route: '/dashboard5' },
    { text: 'Payment History', icon: <PaidIcon />, route: '/paymenthistory' },
    { text: 'Offline Registered', icon: <PersonOutlineIcon />, route: '/admindashboard' },
    
    { text: 'Renewal', icon: <AutorenewIcon />, route: '/renewal' },
    { text: 'Add Members', icon: <GroupAddIcon />, route: '/gymcourse' }
  ];

  const drawer = (
    <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%', backgroundColor: '#ff9800', color: 'white' }}>
      <List>
        {menuItems.map(({ text, icon, route }) => (
          <ListItem key={text} disablePadding>
            <ListItemButton onClick={() => handleNavigation(route)}>
              <ListItemIcon sx={{ color: 'white' }}>{icon}</ListItemIcon>
              <ListItemText primary={text} sx={{ color: 'white' }} />
            </ListItemButton>
          </ListItem>
        ))}
      </List>
  
      <Box sx={{ flexGrow: 1 }}></Box>
  
      <List>
        <ListItem disablePadding>
          <ListItemButton onClick={() => handleNavigation('/logout')}>
            <ListItemIcon sx={{ color: 'white' }}>
              <ExitToAppOutlined />
            </ListItemIcon>
            <ListItemText primary="LogOut" sx={{ color: 'white' }} />
          </ListItemButton>
        </ListItem>
      </List>
    </Box>
  );
  
  const container = window !== undefined ? () => window().document.body : undefined;

  return (
    <>
      <AppBar position="fixed" sx={{ zIndex: 1200, backgroundColor: '#ffffff', color: '#000' }}>
        <Toolbar>
          <IconButton
            edge="start"
            onClick={handleDrawerToggle}
            sx={{ mr: 2, display: { sm: 'none' } }}
          >
            <MenuIcon />
          </IconButton>
          <Typography variant="h6">
            Gym Management System
          </Typography>
        </Toolbar>
      </AppBar>

      <Box sx={{ display: 'flex', mt: '64px' }}>
      <Drawer
  container={container}
  variant="temporary"
  open={mobileOpen}
  onClose={handleDrawerToggle}
  ModalProps={{ keepMounted: true }}
  sx={{
    display: { xs: 'block', sm: 'none' },
    '& .MuiDrawer-paper': { boxSizing: 'border-box', width: drawerWidth, backgroundColor: '#ff9800' },
  }}
>
  {drawer}
</Drawer>

<Drawer
  variant="permanent"
  sx={{
    display: { xs: 'none', sm: 'block' },
    '& .MuiDrawer-paper': { width: drawerWidth, backgroundColor: '#ff9800', mt: '64px' },
  }}
  open
>
  {drawer}
</Drawer>


        <Box component="main" sx={{ flexGrow: 1, p: 3, ml: { sm: `${drawerWidth}px` } }}>
          <Grid container spacing={3} justifyContent="center">
            <Grid item xs={12} md={8}>
              <Card sx={{ p: 3, textAlign: 'center', boxShadow: 3 }}>
                <CardContent>
                  <Typography variant="h5" sx={{ fontWeight: 'bold' }}>New To Register</Typography>
                  <Typography variant="body1" color="textSecondary" sx={{ mb: 2 }}>
                    Register new gym members quickly and easily.
                  </Typography>
                  <Button
                    variant="contained"
                    sx={{ backgroundColor: '#1976D2', color: 'white', p: 2, mt: 1 }}
                    startIcon={<PersonAddIcon />}
                    onClick={() => handleNavigation('/register')}
                  >
                    Register Now
                  </Button>
                </CardContent>
              </Card>
            </Grid>

           
            </Grid>
      
        </Box>
      </Box>
    </>
  );
};

OfflineRegister.propTypes = {
  window: PropTypes.func,
};

export default OfflineRegister;
