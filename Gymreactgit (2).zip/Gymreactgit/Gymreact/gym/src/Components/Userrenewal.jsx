// import React, { useState, useEffect } from "react";
// import { useNavigate } from "react-router-dom";
// import axios from "axios";
// import {
//   AppBar,
//   Toolbar,
//   Typography,
//   Table,
//   TableBody,
//   TableCell,
//   TableContainer,
//   TableHead,
//   TableRow,
//   Paper,
//   Box,
// } from "@mui/material";

// const UserRenewals = () => {
//   const navigate = useNavigate();
//   const userName = sessionStorage.getItem("userName"); // Get logged-in user's name
//   const [renewals, setRenewals] = useState([]);

//   useEffect(() => {
//     if (userName) {
//       fetchRenewals();
//     } else {
//       alert("User not logged in!");
//       navigate("/login"); // Redirect to login if no user session found
//     }
//   }, []);

//   const fetchRenewals = async () => {
//     try {
//       const response = await axios.get(
//         `http://localhost/gymreact/controllers/api/User/Viewrenewals.php?name=${userName}`
//       );
//       if (response.data.success) {
//         setRenewals(response.data.renewals);
//       } else {
//         setRenewals([]); // No records found, set empty array
//       }
//     } catch (error) {
//       console.error("Error fetching renewals:", error);
//       alert("An error occurred while fetching renewals.");
//     }
//   };

//   return (
//     <div>
//       <AppBar position="static">
//         <Toolbar>
//           <Typography variant="h6">Renewal History</Typography>
//           <Box sx={{ flexGrow: 1 }} />
//         </Toolbar>
//       </AppBar>

//       <TableContainer component={Paper} style={{ marginTop: 20, width: "90%", margin: "auto" }}>
//         <Table>
//           <TableHead>
//             <TableRow>
//             <TableCell><strong>Name</strong></TableCell>

//               <TableCell><strong>Membership</strong></TableCell>
//               <TableCell><strong>Trainingplan</strong></TableCell>

//               <TableCell><strong>Amount (₹)</strong></TableCell>
//               <TableCell><strong>Current End Date</strong></TableCell>
//             </TableRow>
//           </TableHead>
//           <TableBody>
//             {renewals.length > 0 ? (
//               renewals.map((renewal, index) => (
//                 <TableRow key={index}>
//                   <TableCell>{renewal.Name}</TableCell>

//                   <TableCell>{renewal.Membership}</TableCell>
//                   <TableCell>{renewal.Trainingplan}</TableCell>

//                   <TableCell>{renewal.Amount}</TableCell>
//                   <TableCell>{renewal.enddate}</TableCell>
//                 </TableRow>
//               ))
//             ) : (
//               <TableRow>
//                 <TableCell colSpan={3} style={{ textAlign: "center" }}>
//                   No renewal records found.
//                 </TableCell>
//               </TableRow>
//             )}
//           </TableBody>
//         </Table>
//       </TableContainer>
//     </div>
//   );
// };

// export default UserRenewals;
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import {
  AppBar,
  Toolbar,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Box,
} from "@mui/material";

const UserRenewals = () => {
  const navigate = useNavigate();
  const userName = sessionStorage.getItem("userName");
  const [renewals, setRenewals] = useState([]);

  useEffect(() => {
    fetchRenewals();
  }, []);

  const fetchRenewals = async () => {
    try {
      const response = await axios.get(
        `http://localhost/gymreact/controllers/api/User/Viewrenewals.php?name=${userName}`
      );
      if (response.data.success) {
        const updatedRenewals = response.data.renewals.map((renewal) => ({
          ...renewal,
          status: localStorage.getItem(`renewal_${renewal.id}`) || "Pending",
        }));
        setRenewals(updatedRenewals);
      }
    } catch (error) {
      console.error("Error fetching renewals:", error);
      alert("An error occurred while fetching renewals.");
    }
  };

  return (
    <div>
      <AppBar position="static">
        <Toolbar>
          <Typography variant="h6">Renewal History</Typography>
          <Box sx={{ flexGrow: 1 }} />
        </Toolbar>
      </AppBar>

      <TableContainer component={Paper} style={{ marginTop: 20, width: "90%", margin: "auto" }}>
        <Table>
          <TableHead>
            <TableRow>
            <TableCell><strong>Name</strong></TableCell>

              
              <TableCell><strong>Membership</strong></TableCell>
              <TableCell><strong>Trainingplan</strong></TableCell>

              <TableCell><strong>Amount (₹)</strong></TableCell>
              <TableCell><strong>Current End Date</strong></TableCell>
              <TableCell><strong>Status</strong></TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {renewals.map((renewal, index) => (
              <TableRow key={index}>
                <TableCell>{renewal.Name}</TableCell>

                <TableCell>{renewal.Membership}</TableCell>
                <TableCell>{renewal.Trainingplan}</TableCell>

                <TableCell>{renewal.Amount}</TableCell>
                <TableCell>{renewal.enddate}</TableCell>
                <TableCell>{renewal.status}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </div>
  );
};

export default UserRenewals;

