import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  Grid,
  Box,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  TextField,
} from "@mui/material";
import gymCourseImage from "../assets/ghym2.png";
import "./Userdashboard.css"; // External CSS for styling

const Userdashboard = () => {
  const navigate = useNavigate();

  const [open, setOpen] = useState(false);
  const [selectedMembership, setSelectedMembership] = useState({
    name: "",
    training: "",
    price: "",
    duration: 0,
  });
  const [userName, setUserName] = useState("");
  const [joiningDate, setJoiningDate] = useState("");
  const [endingDate, setEndingDate] = useState("");

  const memberships = [
    { name: "3-Month Gym Membership", training: "Full Body Training", price: 3000, duration: 3 },
    { name: "6-Month Gym Membership", training: "Strength & Conditioning", price: 6000, duration: 6 },
    { name: "1-Year Gym Membership", training: "Pro Athlete Plan", price: 15000, duration: 12 },
  ];

  const handleJoinNow = (membership) => {
    setSelectedMembership(membership);
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setUserName("");
    setJoiningDate("");
    setEndingDate("");
  };

  const handleJoiningDateChange = (e) => {
    const selectedDate = new Date(e.target.value);
    setJoiningDate(e.target.value);

    if (!isNaN(selectedDate.getTime())) {
      const endDate = new Date(selectedDate);
      endDate.setMonth(endDate.getMonth() + selectedMembership.duration);
      setEndingDate(endDate.toISOString().split("T")[0]);
    }
  };

  const handleSubmit = async () => {
    if (!userName || !joiningDate || !endingDate) {
      alert("Please fill all fields.");
      return;
    }

    const paymentData = {
      Membership: selectedMembership.name,
      Trainingplan: selectedMembership.training,
      Amount: selectedMembership.price,
      Name: userName,
      joindate: joiningDate,
      enddate: endingDate,
    };

    try {
      const response = await axios.post(
        "http://localhost/gymreact/controllers/api/User/userpayment.php",
        paymentData
      );

      if (response.data.success) {
        alert("Payment successfully recorded!");
        setOpen(false);
      } else {
        alert("Payment failed: " + response.data.message);
      }
    } catch (error) {
      console.error("Error submitting payment:", error);
      alert("An error occurred. Please try again.");
    }
  };

  const handleLogout = () => {
    navigate("/");
  };

  return (
    <Box className="dashboard-container">
      <AppBar position="static" className="navbar">
        <Toolbar className="navbar-toolbar">
          <Typography variant="h6" className="navbar-title">
            Gym Membership
          </Typography>
          <div className="navbar-buttons">
            {/* <Button color="inherit">View Payments</Button> */}
            <Button
  color="inherit"
  onClick={() => navigate("/userpayment", { state: { userName } })}
>
  View Payments
</Button>
<Button
  color="inherit"
  onClick={() => navigate("/userrenewal", { state: { userName } })}
>
  Renewal
  </Button>

            {/* <Button color="inherit">Renewal</Button> */}
            <Button color="inherit" onClick={handleLogout}>
              Logout
            </Button>
          </div>
        </Toolbar>
      </AppBar>

      <Grid container spacing={3} justifyContent="center">
        {memberships.map((membership, index) => (
          <Grid key={index} item xs={12} sm={6} md={4}>
            <div className="card">
              <img src={gymCourseImage} alt="Gym Course" className="course-img" />
              <p className="course-title">{membership.name}</p>
              <p className="course-desc">{membership.training}</p>
              <p className="course-price">₹{membership.price}</p>
              <Button
                variant="contained"
                className="join-button"
                onClick={() => handleJoinNow(membership)}
              >
                Join Now
              </Button>
            </div>
          </Grid>
        ))}
      </Grid>

      <Dialog open={open} onClose={handleClose}>
        <DialogTitle>Payment Details</DialogTitle>
        <DialogContent>
          <p>
            <strong>Membership:</strong> {selectedMembership.name}
          </p>
          <p>
            <strong>Training Plan:</strong> {selectedMembership.training}
          </p>
          <p>
            <strong>Amount:</strong> ₹{selectedMembership.price}
          </p>
          <TextField
            label="Your Name"
            variant="outlined"
            fullWidth
            margin="dense"
            value={userName}
            onChange={(e) => setUserName(e.target.value)}
          />
          <TextField
            label="Joining Date"
            type="date"
            variant="outlined"
            fullWidth
            margin="dense"
            value={joiningDate}
            onChange={handleJoiningDateChange}
            InputLabelProps={{ shrink: true }}
          />
          <TextField
            label="Ending Date"
            type="date"
            variant="outlined"
            fullWidth
            margin="dense"
            value={endingDate}
            InputProps={{ readOnly: true }}
            InputLabelProps={{ shrink: true }}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} color="secondary">
            Cancel
          </Button>
          <Button onClick={handleSubmit} variant="contained" color="primary">
            Submit Payment
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default Userdashboard;
