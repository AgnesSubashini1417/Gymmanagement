import React, { useState } from "react";
import { Grid } from "@mui/material";
import EmailIcon from "@mui/icons-material/Email";
import LockIcon from "@mui/icons-material/Lock";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "../Styles/Task.css";

function UserLogin() {
    const [credentials, setCredentials] = useState({
        email: "",
        password: "",
    });

    const [errors, setErrors] = useState({
        email: "",
        password: "",
    });

    const [errorMessage, setErrorMessage] = useState("");

    const navigate = useNavigate();

    const handleChange = (event) => {
        const { id, value } = event.target;
        setCredentials((prevState) => ({
            ...prevState,
            [id]: value,
        }));
    };

    const handleLogin = async (event) => {
        event.preventDefault();

        // Basic validation
        const newErrors = {
            email: credentials.email ? "" : "Email is required",
            password: credentials.password ? "" : "Password is required",
        };
        setErrors(newErrors);

        if (!credentials.email || !credentials.password) {
            return;
        }

        try {
            const response = await axios.post(
                "http://localhost/gymreact/controllers/api/User/login.php",
                credentials,
                { withCredentials: true } // Enables session cookies
            );

            if (response.data.success) {
                const userName = response.data.name; // Get name from response

                // Store user name in session storage
                sessionStorage.setItem("userName", userName);

                alert("Login successful!");
                navigate("/userdashboard", { state: { userName } }); // Pass name to dashboard
            } else {
                setErrorMessage(response.data.message);
            }
        } catch (error) {
            console.error("Login error:", error);
            setErrorMessage("An error occurred. Please try again.");
        }
    };

    return (
        <Grid container spacing={2} sx={{ flexGrow: 1 }}>
            <Grid item xs={12}>
                <div className="container">
                    <div className="har">
                        <div className="z">
                            <div className="circle"></div>
                            <div className="divider"></div>
                            <div className="gym-name">GYM MANAGEMENT SYSTEM</div>
                        </div>

                        <h1>Login</h1>
                        <form onSubmit={handleLogin}>
                            <div className="inputcont">
                                <EmailIcon className="input-icons" />
                                <input
                                    type="email"
                                    className="input-padding"
                                    placeholder="Email"
                                    id="email"
                                    value={credentials.email}
                                    onChange={handleChange}
                                />
                                {errors.email && <p className="error">{errors.email}</p>}
                            </div>

                            <div className="inputcont">
                                <LockIcon className="input-icons" />
                                <input
                                    type="password"
                                    className="input-padding"
                                    placeholder="Password"
                                    id="password"
                                    value={credentials.password}
                                    onChange={handleChange}
                                />
                                {errors.password && <p className="error">{errors.password}</p>}
                            </div>

                            {errorMessage && <p className="error">{errorMessage}</p>}

                            <div>
                                <button type="submit">LOGIN</button>
                            </div>

                            <p className="register-text">
                                Don't have an account?{" "}
                                <span className="register-link" onClick={() => navigate("/userregister")}>
                                    Register here
                                </span>
                            </p>
                        </form>
                    </div>
                </div>
            </Grid>
        </Grid>
    );
}

export default UserLogin;
