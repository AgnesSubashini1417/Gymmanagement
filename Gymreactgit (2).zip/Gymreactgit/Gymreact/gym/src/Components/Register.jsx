import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import {
  AppBar, Toolbar, Typography, Box, Grid, Card, CardContent, Button, TextField, MenuItem
} from "@mui/material";
import { ArrowBack as ArrowBackIcon } from "@mui/icons-material";
import bgImage from "../assets/ghy1.png"; // Ensure correct path

const Register = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: "",
    age: "",
    gender: "",
    city: "",
    phone: "",
    joiningdate: "",
    Membership: "",
    Payment: "",
    Amount: "",
  });

  // Handle Input Changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  // Handle Form Submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post("http://localhost/gymreact/controllers/api/admin/offlineregister.php", formData);
      if (response.data.success) {
        alert("User registered successfully!");
        setFormData({
          name: "",
          age: "",
          gender: "",
          city: "",
          phone: "",
          joiningdate: "",
          Membership: "",
          Payment: "",
          Amount: "",
        });
      } else {
        alert("Error: " + response.data.message);
      }
    } catch (error) {
      console.error("Error submitting form:", error);
      alert("Failed to register user.");
    }
  };

  return (
    <>
      <AppBar position="fixed" sx={{ backgroundColor: "white", color: "black" }}>
        <Toolbar>
          <Typography variant="h6">Gym Management System</Typography>
        </Toolbar>
      </AppBar>

      <Box
        sx={{
          backgroundImage: `url(${bgImage})`,
          backgroundSize: "cover",
          minHeight: "100vh",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          p: 3,
        }}
      >
        <Grid container spacing={2} maxWidth="500px">
          <Grid item xs={12}>
            <Card sx={{ p: 3, boxShadow: 5, borderRadius: 3, backgroundColor: "rgba(255, 255, 255, 0.92)" }}>
              <CardContent>
                <Typography variant="h5" sx={{ fontWeight: "bold", textAlign: "center", mb: 2 }}>
                  New Member Registration
                </Typography>

                <form onSubmit={handleSubmit}>
                  <TextField fullWidth margin="normal" label="Name" name="name" value={formData.name} onChange={handleInputChange} required />
                  <TextField fullWidth margin="normal" label="Age" name="age" type="number" value={formData.age} onChange={handleInputChange} required />
                  <TextField fullWidth margin="normal" select label="Gender" name="gender" value={formData.gender} onChange={handleInputChange} required>
                    <MenuItem value="Male">Male</MenuItem>
                    <MenuItem value="Female">Female</MenuItem>
                    <MenuItem value="Other">Other</MenuItem>
                  </TextField>
                  <TextField fullWidth margin="normal" label="City" name="city" value={formData.city} onChange={handleInputChange} required />
                  <TextField fullWidth margin="normal" label="Phone" name="phone" type="tel" value={formData.phone} onChange={handleInputChange} required />
                  <TextField fullWidth margin="normal" label="Joining Date" name="joiningdate" type="date" InputLabelProps={{ shrink: true }} value={formData.joiningdate} onChange={handleInputChange} required />
                  <TextField fullWidth margin="normal" select label="Membership Duration" name="Membership" value={formData.Membership} onChange={handleInputChange} required>
                    <MenuItem value="1 Month">1 Month</MenuItem>
                    <MenuItem value="3 Months">3 Months</MenuItem>
                    <MenuItem value="6 Months">6 Months</MenuItem>
                    <MenuItem value="1 Year">1 Year</MenuItem>
                  </TextField>
                  <TextField fullWidth margin="normal" select label="Payment Mode" name="Payment" value={formData.Payment} onChange={handleInputChange} required>
                    <MenuItem value="Cash">Cash</MenuItem>
                  </TextField>
                  <TextField fullWidth margin="normal" label="Amount" name="Amount" type="number" value={formData.Amount} onChange={handleInputChange} required />

                  <Button fullWidth variant="contained" sx={{ mt: 2 }} type="submit">Submit</Button>
                  <Button fullWidth variant="outlined" sx={{ mt: 2 }} startIcon={<ArrowBackIcon />} onClick={() => navigate("/offline")}>Back</Button>
                </form>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      </Box>
    </>
  );
};

export default Register;
